import unittest
import re

def US32_pass():
    f = open("U32familypass.csv", "r")
    fString = f.read()

    flist = []
    for line in fString.split("\n"):
        flist.append(line.split(","))

    del flist[0]

    flag = 0
    for i in range(len(flist) - 1):
        list = re.findall(r'\S+', flist[i][7])
        if len(list) > 1:
            flag = 1
            print('ERROR: FAMILY: US32:  The Family ' + flist[i][0] + ' have multiple births  ' + flist[i][7])

    if flag == 1:
        return False
    else:
        return True


def US32_fail():
    f = open("U32familyfail.csv", "r")
    fString = f.read()

    flist = []
    for line in fString.split("\n"):
        flist.append(line.split(","))

    del flist[0]

    flag = 0
    for i in range(len(flist) - 1):
        list = re.findall(r'\S+', flist[i][7])
        if len(list) > 1:
            flag = 1

    if flag == 1:
        return False
    else:
        return True


class TestCase(unittest.TestCase):
    def test_decreasing_children(self):
        self.assertTrue(US32_pass())
        self.assertFalse(US32_fail())


if __name__ == "__main__":
    unittest.main()
