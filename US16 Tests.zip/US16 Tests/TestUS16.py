import unittest
import re

def US16_pass():
    i = open("U16indipass.csv", "r")
    iString = i.read()

    ilist = []
    for line in iString.split("\n"):
        ilist.append(line.split(","))

    f = open("U16familypass.csv", "r")
    fString = f.read()

    flist = []
    for line in fString.split("\n"):
        flist.append(line.split(","))

    del flist[0]
    child_list = []
    flag = 0

    for i in range(len(flist) - 1):
        surname = flist[i][4][flist[i][4].index('/'):]
        list = re.findall(r'\S+', flist[i][7])
        for l in range(len(list) - 1):
            for p in range(len(ilist) - 1):
                if (list[l] == ilist[p][0]) and (ilist[p][2] == 'M'):
                    child_list.append(ilist[p][1])

        for i in child_list:
            child_surname = i[i.index('/'):]
            if surname != child_surname:
                flag = 1
                print('ERROR: INDIVIDUAL: US16:   ' + i + ' has a different surname in the family')

    if flag == 1:
        return False
    else:
        return True


def US16_fail():
    i = open("U16indifail.csv", "r")
    iString = i.read()

    ilist = []
    for line in iString.split("\n"):
        ilist.append(line.split(","))

    f = open("U16familyfail.csv", "r")
    fString = f.read()

    flist = []
    for line in fString.split("\n"):
        flist.append(line.split(","))

    del flist[0]
    child_list = []
    flag = 0

    for i in range(len(flist) - 1):
        surname = flist[i][4][flist[i][4].index('/'):]
        list = re.findall(r'\S+', flist[i][7])
        for l in range(len(list) - 1):
            for p in range(len(ilist) - 1):
                if (list[l] == ilist[p][0]) and (ilist[p][2] == 'M'):
                    child_list.append(ilist[p][1])

        for i in child_list:
            child_surname = i[i.index('/'):]
            if surname != child_surname:
                flag = 1


    if flag == 1:
        return False
    else:
        return True


class TestCase(unittest.TestCase):
    def test_decreasing_children(self):
        self.assertTrue(US16_pass())
        self.assertFalse(US16_fail())


if __name__ == "__main__":
    unittest.main()
